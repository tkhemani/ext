"use strict";

$(document).ready(() => {
    activateKeyPressedHandlers();
});

function activateKeyPressedHandlers() {
    const keyPressedHandlers = {
        "q": sortAllListEntries
    };

    $(document).keypress(eventObject => {
        const keyPressed = String.fromCharCode(eventObject.which);

        const keyPressedHandler = keyPressedHandlers[keyPressed];
        if (keyPressedHandler) {
            keyPressedHandler();
        }
    });
}

function sortAllListEntries() {
    const sections = $(".list-entries").toArray();
    sections.forEach(section => {
        const entries = $(section).find(".entry").toArray();

        sortListEntries(entries);
    });
}

function sortListEntries(entries) {
    entries
        .sort((a, b) => {
            const compareByTitle = () => {
                const getTitleOfEntry = entry => $(entry).find(".content .title")[0].innerHTML;

                return getTitleOfEntry(b).localeCompare(getTitleOfEntry(a));
            };

            const compareByEngagement = () => {
                const getEngagementOfEntry = entry => Number(($(entry).find(".engagement")[0] || $("<div>0</div>")[0]).innerHTML.replace("K", "000").replace("+", ""));

                const engagementOfA = getEngagementOfEntry(a);
                const engagementOfB = getEngagementOfEntry(b);

                return engagementOfA === engagementOfB ? null : engagementOfA < engagementOfB ? -1 : +1;
            };

            return compareByEngagement() || compareByTitle();
        })
        .forEach(entry => {
            entry.parentNode.insertBefore(entry, entry.parentNode.firstChild);
        });
}
