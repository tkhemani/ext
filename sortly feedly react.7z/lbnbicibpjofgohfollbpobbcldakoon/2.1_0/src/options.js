$(document).ready(() => {
    const version = chrome.app.getDetails().version;

    $("#versionLabel").text(version);
});
